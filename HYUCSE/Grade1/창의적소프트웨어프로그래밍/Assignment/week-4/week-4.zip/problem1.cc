#include <iostream>

int* array;
size_t cap = 0;

void initialize(int cap_) {
    array = new int[cap_];
    cap = cap_;
}

void release() {
    delete[] array;
}

void push_back(int element) {
    // TODO:
    // insert element to back of array
    // if array is [1,2,3], and push_back(4) called,
    // then array should be [1,2,3,4]

    array = (int*)realloc(array,cap+1);
    array[cap] = element;
    cap++;

}

int pop_back() {
    // TODO:
    // return last element of array and remove it from array
    // if array is [1,2,3,4] and pop_back() called,
    // then array should be [1,2,3] and pop_back() return 4.

    int returnNum = array[cap-1];
    array = (int*) realloc(array,cap-1);
    cap--;
    return returnNum;    

}

int len() {
    // TODO:
    // return size of array
    return cap;
}

int main() {

    initialize(3);

    std::cout << "len : " << len() << std::endl;

    array[0] = 1;
    array[1] = 2;
    array[2] = 3;

    std::cout << "len : " << len() << std::endl;

    for(int i = 0; i < 3; i++){
        push_back(i+4);
    }
    for(int i = 0; i < 6; i++){
        std::cout << array[i] << std::endl;
    }

    std::cout << "len : " << len() << std::endl;

    for(int i = 5; i >= 0; i--){
        std::cout << pop_back() << std::endl;
    }

    std::cout << "len : " << len() << std::endl;

    return 0;
}